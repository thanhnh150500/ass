<!DOCTYPE html>
<html>
<head>
    <title>Fitness</title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
    <link rel="icon" href="images/gym.png" type="image/x-icon" />
</head>
<body>
    <!-- header menu -->
     <div id="top-menu">
        <img href="#" class="logo-form" src="https://adrenalinemonkeyfun.com/wp-content/uploads/2018/02/fitness-768x307.png" />
        <input class="search-text" placeholder="Search...">
        <button class="submit" type="submit"><i class="search-icon"></i></button>
        <a class="hotline" type="hotline"><i class="phone-icon">0123456789</i></a>
        <a class="login"><i class="login-icon">Login</i></a>
        <a class="register"><i class="register-icon">Register</i></a>
    </div>

    <!-- navigation menu-->
    <div id="navigation-menu">
        <div class="menu-wrapper">
            <div class="item-wrapper">
                <div class="dropdown-toggle homepage">Trang chủ</div>
            </div>
            <div class="item-wrapper">
                <div class="dropdown-toggle">Dịch vụ</div>
                <div class="dropdown-content">
                    <a href="#">Giảm cơ tăng mỡ</a>
                    <a href="#">Yoga</a>
                    <a herf="#">HLV cá nhân</a>
                    <a herf="#">kickfit</a>
                </div>
            </div>
            <div class="item-wrapper">
                <a class="dropdown-toggle blog">Blog</a>
            </div>
            <div class="item-wrapper">
                <div class="dropdown-toggle knowledge">Kiến thức thể hình</div>
                <div class="dropdown-content">
                    <a href="#">Kiến thức cơ bản</a>
                    <a href="#">Kiến thức nâng cao</a>
                    <a href="#">Kiến thức sử dụng TPBS</a>
                </div>
            </div>
            <div class="item-wrapper">
                <div class="dropdown-toggle exercises">Bài tập Gym</div>
                <div class="dropdown-content">
                    <a href="#">Chân, mông, đùi</a>
                    <a href="#">Lưng</a>
                    <a href="#">Ngực</a>
                    <a href="#">Vai</a>
                    <a href="#">Tay ( Trước/ Sau )</a>
                    <a href="#">Bụng</a>
                    <a href="#">Cardio</a>
                </div>
            </div>
            <div class="item-wrapper">
                <div class="dropdown-toggle lesson-plan">Giáo án</div>
                <div class="dropdown-content">
                    <a href="#">Mới tập- Tháng (0-2)</a>
                    <a href="#">Trung bình- Tháng (3-5)</a>
                    <a href="#">Tăng cơ- Tháng (6-12)</a>
                    <a href="#">Giảm mỡ- Tháng (6-12)</a>
                    <a href="#">Nâng cao</a>
                </div>
            </div>
            <div class="item-wrapper">
                <div class="dropdown-toggle store">Cửa hàng</div>
                <div class="dropdown-content">
                    <a href="#">Whey protein</a>
                    <a href="#">Protein hoàn chỉnh</a>
                    <a href="#">Năng lượng trước/sau tập</a>
                    <a href="#">Amino axti- BCAA</a>
                    <a href="#">Mass tăng cân, cơ</a>
                    <a href="#">Giảm mỡ- Fat burner</a>
                    <a href="#">Vitamin</a>
                </div>
            </div>
        </div>
    </div>

    <div id="main">
        <!-- banner -->
        <div id="banner">
            <i class="arrow-left"></i>
            <i class="arrow-right"></i>
            <img class="advertisment" src="images/The-Gym-15.jpg" />
        </div>
    </div>
     
    <!-- wrapper -->
    <div id="wrapper">
        <div class="main-wrapper">
            <div class="training">
                <div class="title">
                    <a class="title-a">Kiến thức thể hình</a>
                </div>
                    <div class="desc">
                        <div class="row">
                            <img class="thumbnail sweet" src="images/sweet.jpg" href="#" />
                            <a class="thumbnail-description">Tác hại khi tiêu thụ quá nhiều đường</a>
                        </div> 
                        <div class="row">
                            <img class="thumbnail deviation" src="images/muscle-deviation.jpg" href="#"/>
                            <a class="thumbnail-description">Cách khắc phục lệch cơ</a>
                        </div>
                        <div class="row">
                            <img class="thumbnail squat" src="images/squat.jpg" href="#" />
                            <a class="thumbnail-description">Những vấn đề trong squat và giải pháp</a>
                        </div>
                        <div class="row">
                            <img class="thumbnail protein" src="images/protein.jpg" href="#" />
                            <a class="thumbnail-description">Protein là gì ? Kiến thức cần biết </a>
                        </div>
                    </div> 
                <div class="title">
                    <a class="title-b">Dinh dưỡng thể hình</a>
                </div>
                <div class="desc">
                    <div class="row">
                        <img class="thumbnail supplement" src="images/supplement.jpg" href="#" />
                        <a class="thumbnail-description">Hướng dẫn về cách sử dụng thực phẩm bổ sung</a>
                    </div>
                    <div class="row">
                        <img class="thumbnail supplement" src="images/muscle-develop.jpg" href="#" />
                        <a class="thumbnail-description">Thực phẩm giúp xây dựng cơ bắp</a>
                    </div>
                    <div class="row">
                        <img class="thumbnail supplement" src="images/steroid.png" href="#" />
                        <a class="thumbnail-description">Ảnh hưởng của steroid và việc lạm dụng anabolic steroids</a>
                    </div>
                    <div class="row">
                        <img class="thumbnail supplement" src="images/eggs.jpg" href="#" />
                        <a class="thumbnail-description">Nên ăn bao nhiêu quả trứng 1 tuần? </a>
                    </div>
                </div>
                <div class="block-row">
                    <div class="title-c">
                        <a class="title-d">Videos hướng dẫn tập luyện </a>
                    </div>
                    <div class="desc">
                        <div class="row">
                            <iframe width="400" height="500" src="https://www.youtube.com/embed/Y_7aHqXeCfQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            <a class="thumbnail-description">Hướng dẫn tập Bench Press</a>
                        </div>
                        <div class="row">
                            <iframe width="400" height="500" src="https://www.youtube.com/embed/ytGaGIn3SjE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            <a class="thumbnail-description">Hướng dẫn deadlift</a>
                        </div>
                        <div class="row">
                            <iframe width="400" height="500" src="https://www.youtube.com/embed/nEQQle9-0NA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            <a class="thumbnail-description">Hướng dẫn Squad</a>
                        </div>
                        <div class="row">
                            <iframe width="400" height="500" src="https://www.youtube.com/embed/jv31A4Ab4nA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            <a class="thumbnail-description">Hướng dẫn shoulder</a>
                        </div>
                    </div>
                </div>
                <div class="title">
                    <a class="title-e">Tin tức thể hình</a>
                </div>
                <div class="desc">
                    <div class="block-row-1">
                        <img class="news" src="images/chulsoon.jpg" />
                        <a class="topic">Nguyễn Hữu Thành Vs Chul Soon – Ai mới là gương mặt nổi trội làng thể hình ?<a>
                    </div>
                    <div class="block-row-2">
                        <ul class="block-row-3">
                            <li class="others-news">Top 10 huấn luyện viên thể hình online cho Thành tốt nhất</li>
                            <li class="others-news">Có bụng 6 múi không khó, không đổ mồ hôi nhờ….Thành</li>
                            <li class="others-news">4 sự thật khủng khiếp trong nghề Bodybuilding chuyên nghiệp</li>
                            <li class="others-news">Nguyễn Hữu Thành 5 lần vô địch thế giới, mang về vinh quang cho thể hình Việt</li>
                        </ul>
                    </div>
                    <div class="block-row-4">
                        <ul class="block-row-5">
                            <img class="Yoga" src="images/Yoga.jpg" />
                            <li class="topic-yoga">3 động tác yoga giảm mỡ bụng mà Thành đang tìm kiếm</li>
                        </ul>
                        <ul class="block-row-6">
                            <img class="Yoga" src="images/Yoga-2.gif" />
                            <li class="topic-yoga">6 tư thế yoga trẻ hóa làn da</li>
                        </ul>
                        <ul class="block-row-6">
                            <img class="Yoga" src="images/Yoga-3.jpg" />
                            <li class="topic-yoga">Yoga giảm cân: Ăn gì trước và sau khi tập để giảm cân nhanh?</li>
                        </ul>
                        <ul class="block-row-6">
                            <img class="Yoga" src="images/Yoga-4.jpg" />
                            <li class="topic-yoga">Tập yoga giảm cân toàn thân nhanh với 10 bài đơn giản</li>
                        </ul>
                        <ul class="block-row-6">
                            <img class="Yoga" src="images/Yoga-5.jpg" />
                            <li class="topic-yoga">Tự học yoga tại nhà</li>
                        </ul>
                    </div>
                </div>
                <div class="title">
                    <a class="title-f">Chạy bộ</a>
                </div>
                <div class="desc">
                    <div class="row">
                        <img class="thumbnail trail" src="images/trail.png" href="#" />
                        <a class="thumbnail-description">Kinh nghiệm nâng cao khi bò trail</a>
                    </div>
                    <div class="row">
                        <img class="thumbnail stair" src="images/stair.jpg" href="#" />
                        <a class="thumbnail-description">Lợi ích của việc bò cầu thang</a>
                    </div>
                    <div class="row">
                        <img class="thumbnail mistake-run" src="images/mistake-run.jpg" href="#" />
                        <a class="thumbnail-description">Những lỗi chạy bộ đúng cách</a>
                    </div>
                    <div class="row">
                        <img class="thumbnail nutrition" src="images/nutrition.jpg" href="#" />
                        <a class="thumbnail-description">Dinh dưỡng sau khi ăn</a>
                    </div>
                </div>
            </div>
        </div>    
    </div>

    <!--footer-->

    <div id="footer">
        <div class="brands">
            <img class="logo-brands" src="images/footer-logo.png">
            <img class="logo-brands" src="images/footer-logo2.png">
            <img class="logo-brands" src="images/footer-logo3.png">
            <img class="logo-brands" src="images/footer-logo4.png">
            <img class="logo-brands" src="images/footer-logo5.png">                
        </div>                           
        <div class="footer-logo">
            <img href="#" class="logo-form" src="https://adrenalinemonkeyfun.com/wp-content/uploads/2018/02/fitness-768x307.png" />
            <a class="footer-logo-text">Fitness là kênh hướng dẫn các bạn Gymer tập luyện thể hình chuyên nghiệp, với các giáo án thể hình kèm và các bài tập được hướng dẫn chi tiết, phù hợp với tất cả đối tượng từ cơ bản đến nâng cao. Chúc các bạn mau chóng có được Body đẹp cùng Fitness </a>
        </div>
        <div class="footer-1">
            <a class="uppercase">DỊCH VỤ</a>
            <ul class="list-service">
                <li class="list-name">
                    <a class="name">Giảm tăng cơ</a>
                </li>
                <li class="list-name">
                    <a class="name">Dance</a>
                </li>
                <li class="list-name">
                    <a class="name">Yoga</a>
                </li>
                <li class="list-name">
                    <a class="name">HLV cá nhân</a>
                </li>
                <li class="list-name">
                    <a class="name">PTX</a>
                </li>
                <li class="list-name">
                    <a class="name">MMA/kickfit</a>
                </li>
                <li class="list-name">
                    <a class="name">Giảm cân</a>
                </li>
            </ul>
        </div>
        <div class="footer-1">
            <a class="uppercase">LIÊN KẾT</a>
            <ul class="list-link">
                <li class="list-name">
                    <a class="name">Tuyển dụng</a>
                </li>
                <li class="list-name">
                    <a class="name">Góp ý - Phản hồi</a>
                </li>
                <li class="list-name">
                    <a class="name">Điều kiện sử dụng</a>
                </li>
                <li class="list-name">
                    <a class="name">Chính sách bảo mật</a>
                </li>
            </ul>
        </div>
        <div class="footer-1">
            <a class="uppercase">LIÊN HỆ</a>
            <div class="list-contact">
                <i class="icon-phone"></i>
                <a class="phone-number">0123456789 |</a>
                <a class="phone-number">084123456</a>
            </div>
            <div class="list-mail">
                <i class="icon-mail"></i>
                <a class="mail-text">fitness.com.vn</a>
            </div>
            <div class="list-apps">
                <i class="icon-youtube"></i>
                <a class="mail-text">123</a>
            </div>
        </div>
    </div>                               
</body>
</html>